package modele;
import java.util.*;
/**
 * This is the class to prepare all the thing which will be used in one game.
 * And It can get the final winner.
 * 
 *
 */
public class PartieDeJeu extends Observable {
	public static List<Player> playerlist;
	public static List<Prop> propOrginal;
	public TrickDeck trickdeck;
	public TrickPile trickpile;
	public Prop7th prop7th;
	public int numcourrent=0;
	/**
	 * This is the constructor of the class PartieDeJeu.
	 * 
	 * @param playerlist is an arraylist to stock the players.
	 * @param propOriginal is an arraylist to stock all the props.
	 * @param prop7th is a prop to stock the first prop in the propOriginal which has been shuffled.
	 * @param trickdeck is an arraylist to stock all the trick inthe first.
	 * @param trickpile is an empty arraylist.
	 */
	public PartieDeJeu() {
		PartieDeJeu.playerlist = new ArrayList<Player>();
		PartieDeJeu.propOrginal = new ArrayList<Prop>();
		this.createProp();
		Collections.shuffle(PartieDeJeu.propOrginal);
		this.prop7th=new Prop7th();
		Prop7th.p7 = PartieDeJeu.propOrginal.get(0);
		this.trickdeck=new TrickDeck();
		this.trickpile=new TrickPile();
		
	}
	/**
	 * This is the operation to show now is which player is playing.
	 */
	public void nextPlayer() {
		int i=1;
		this.setChanged();
		this.notifyObservers(i);
	}
	/**
	 * This is the operation to create all the player.
	 * 
	 * @param n is the number of the real players.
	 * @param c is the mode easy or hard.
	 * @param age is a list of players'ages.
	 */
	public void createplayer(int n, char c, int[] age) {
	
		
		if(c=='e') {
			for(int i=0;i<n;i++) {
				PartieDeJeu.playerlist.add(new RealPlayer(age[i]));
			}
			for(int i=n;i<3;i++) {
				PartieDeJeu.playerlist.add(new VirtualPlayer());
			}
		}
		
		if(c=='h'){
			for(int i=0;i<n;i++) {
				PartieDeJeu.playerlist.add(new RealPlayer(age[i]));
			}

			for(int i=n;i<3;i++) {
				PartieDeJeu.playerlist.add(new VirtualPlayerHard());
			}
		}

		Collections.sort(PartieDeJeu.playerlist);
	}
	/**
	 * This is the operation to create all the Prop.
	 */
	public void createProp() {
		boolean m = false;
		for(PropCard pc:PropCard.values()) {
			if(pc==PropCard.Carrots) {
				for(int i=0;i<3;i++)
					PartieDeJeu.propOrginal.add(new Prop(pc,m));
			}
			else {
				PartieDeJeu.propOrginal.add(new Prop(pc,m));
			}
		}
	}
	/**
	 * This is the operation to deal props to player.
	 * 
	 * @param list which stocks all the player.
	 * @param propO which stocks all the shuffled props.
	 */
	public void dealProp(List<Player> list, List<Prop> propO) {
		(list.get(0)).setPropleft (propO.get(1));
		(list.get(0)).setPropright(propO.get(2));
		(list.get(1)).setPropleft (propO.get(3));
		(list.get(1)).setPropright(propO.get(4));
		(list.get(2)).setPropleft (propO.get(5));
		(list.get(2)).setPropright(propO.get(6));
	}
	
	/**
	 * This is the operation to use two operations {@code createplayer(),@code dealProp()}.
	 * 
	 * @param n is the number of the real players.
	 * @param c is the mode easy or hard.
	 * @param age is a list of players'ages.
	 */
	public void preparePlayer(int n,char c,int[] age) {
		createplayer(n,c,age);
		dealProp(PartieDeJeu.playerlist, PartieDeJeu.propOrginal);
	}
	/**
	 * This is the first way to end game.
	 * 
	 * @return the number of the winner.
	 */
	public int winner1() {
		int max=0;
    	int winner =0;
    	for(int i=0;i<3;i++) {
    		if(PartieDeJeu.playerlist.get(i).getScore()>max) {
    			max=PartieDeJeu.playerlist.get(i).getScore();
    			winner=i;
    			
    		}
		}
    	return winner;
	}
	/**
	 * This is another way to end game.
	 * 
	 * @return the number of the winner.
	 */
	public int winner2() {
		for(int i=0;i<3;i++) {
			if(PartieDeJeu.playerlist.get(i).getPropleft().getName()  == "The_Hat" ||PartieDeJeu.playerlist.get(i).getPropright().getName()  == "The_Hat" ||PartieDeJeu.playerlist.get(i).getPropleft().getName() == "The_Other_Rabbit"||PartieDeJeu.playerlist.get(i).getPropright().getName() == "The_Other_Rabbit" ) {
				PartieDeJeu.playerlist.get(i).setScore(-3);
			}
    	}
    	int max=0;
    	int winner =0;
    	for(int i=0;i<3;i++) {
    		if(PartieDeJeu.playerlist.get(i).getScore()>max) {
    			max=PartieDeJeu.playerlist.get(i).getScore();
    			winner=i;
    			
    		}
		}
    	return winner;
	}
	
}
