package modele;
/**
 * Class VirualPlayer inherits the class Player and 
 * implements the interface VirtualStrategy.
 * This is the easy mode.
 * 
 *
 */
public class VirtualPlayer extends Player implements VirtualStrategy{
	/**
	 * Constructor of the class VirtualPlayer whose age is 100.
	 * He is always older than RealPlayer.
	 */
	public VirtualPlayer() {
		super(100);
	}
	/**
	 * Always swap his left prop with player p's left prop.
	 */
	public synchronized void swapProp(Player p,int a, int b) {
		Prop pr = new Prop();
		pr=this.getPropleft();
		this.setPropleft(p.getPropleft());
		p.setPropleft(pr);
		this.setChanged();
		this.notifyObservers("Prop");
		p.setChanged();
		p.notifyObservers("Prop");
	}
	/**
	 * Always choose his right prop and the prop7th.
	 */
	public synchronized void rearrange(int newleft, int newright,Prop7th prop7th) {
		Prop pr = new Prop();
		pr=this.getPropleft();
		this.setPropleft(Prop7th.p7);
		Prop7th.p7=pr;
		this.getPropleft().setMark(false);
		this.getPropright().setMark(false);
		this.setChanged();
		this.notifyObservers("Prop");
		prop7th.backProp7th();
	}
	/**
	 * Always flip his left prop.
	 * When his left prop has been flipped, he will flip his right prop.
	 * If all his props have been flipped, he can flip back his left prop.
	 */
	public synchronized void flipProp(int p) {
		if(this.getPropleft().getMark()==true) {
			if(this.getPropright().getMark()==true)
				this.getPropleft().setMark(false);
			else
				this.getPropright().setMark(true);
		}
		else
			this.getPropleft().setMark(true);
		this.setChanged();
		this.notifyObservers("flipped");
	}
	/**
	 * Perform the chosen trick.
	 * If he succeeds, he will take the trick and use the operation rearrange().
	 * If he failed, it will use the opearion flipProp().
	 * 
	 * @param t is the chosen trick.
	 * @param trickdeck is the list to stock trick.
	 * @param trickpile is the list to stock trick.
	 * @param prop7th is to stock a prop7th.
	 * @return whether the performance is success. true or false.
	 */
	public boolean performTrick(Trick t, TrickDeck trickdeck, TrickPile trickpile, Prop7th prop7th) {
		boolean p = false;
		
		for(String x:t.getProp1()){
			for(String y:t.getProp2()) {
				if(((this.getPropleft().getName()==x)&&(this.getPropright().getName()==y))||((this.getPropleft().getName()==y)&&(this.getPropright().getName()==x))) {
					p = true;
					break;
				}
			}
			if(p==true)
				break;
		}
		
		if(p==true) {
			this.setScore(t.getPoint());
			trickpile.removeTrick(TrickPile.tp.get(TrickPile.tp.size()-1));
			if(TrickPile.tp.size()==0&&TrickDeck.td.size()!=0) {
				trickpile.addTrick(TrickDeck.td.get(TrickDeck.td.size()-1));
				TrickDeck.td.remove(TrickDeck.td.size()-1);
			}
			this.getPropleft().setMark(true);
			this.getPropright().setMark(true);
			this.setChanged();
			this.notifyObservers("AIsuccess");
			prop7th.lookProp7th();
			
			return true;
			
		}
		else {
			this.setnbFail();
			t.failtime ++;
			this.setChanged();
			this.notifyObservers("AIfail");
			return false;
		}
		
	}
	/**
	 * Always choose TrickDeck.
	 * If the TrickDeck is empty, he will choose the TrickPile.
	 */
	public synchronized Trick chooseTrick(TrickDeck trickdeck, TrickPile trickpile,int i) {
		Trick tr=new Trick();
		if(TrickDeck.td.size()!=0) {
			trickpile.addTrick(TrickDeck.td.get(TrickDeck.td.size()-1));
			TrickDeck.td.remove(TrickDeck.td.size()-1);
			if(TrickDeck.td.size()==0) {
				trickdeck.setEmpty();
			}
			tr=TrickPile.tp.get(TrickPile.tp.size()-1);
			return tr;
		}
		else {
			tr=TrickPile.tp.get(TrickPile.tp.size()-1);
			return tr;
		}
	}
	
	

}
