package modele;

import java.util.ArrayList;
import java.util.List;
/**
 * This class create a new list to stock the tricks flipped from trick deck.
 * 
 *
 */
public class TrickPile extends Observable{
	public static List<Trick> tp;
	/**
	 * Constructor creates a new list.
	 */
	public TrickPile() {
		TrickPile.tp = new ArrayList<Trick>();
	}
	/**
	 * Add the trick flipped from trick deck.
	 * 
	 * @param t is the trick flipped from trick deck.
	 */
	public void addTrick(Trick t) {
		TrickPile.tp.add(t);
		this.setChanged();
		this.notifyObservers(t);
	}
	/**
	 * If the player has succeeded, the top trick of the trick pile will be removed.
	 * 
	 * @param t is the trick performed.
	 */
	public void removeTrick(Trick t) {
		TrickPile.tp.remove(t);
		this.setChanged();
		this.notifyObservers(t);
	}

}
