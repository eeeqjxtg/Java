package modele;
import vue.Observer;
import java.util.*;
/**
 * This is a father class Observable in the patron de conception.
 * 
 *
 */
public class Observable {
	private HashSet<Observer> observers;
	private boolean hasChanged;
	/**
	 * This is the constructor of the class Observable.
	 * 
	 */
	public Observable() {
		observers=new HashSet<Observer>();
		hasChanged=false;
	}
	/**
	 * This is the operation to add Observer.
	 * 
	 * @param o is the observer which want to be added.
	 */
	public void addObserver(Observer o) {
			observers.add(o);
	}
	/**
	 * This is the operation to delete observer.
	 * 
	 * @param o is the observer which want to be deleted.
	 */
	public void deleteObserver(Observer o) {
		observers.remove(o);
	}
	/**
	 * This is the operation to notify the observers when there is a change.
	 * 
	 * @param o is something which you want to notify the observer.
	 */
	public void notifyObservers(Object o) {
		if(hasChanged==true) {
			for(Iterator<Observer> it=observers.iterator();it.hasNext();) {
				((Observer) it.next()).update(this,o);
			}
			hasChanged=false;
		}
	}
	/**
	 * This is the operation to set the change.
	 * 
	 * @param haschanged is the sign whether there is a change.
	 */
	public void setChanged() {
		hasChanged=true;
	}
	/**
	 * This is the operation to clear the change.
	 * 
	 * @param haschanged is the sign whether there is a change.
	 */
	public void clearChanged() {
		hasChanged=false;
	}
}
