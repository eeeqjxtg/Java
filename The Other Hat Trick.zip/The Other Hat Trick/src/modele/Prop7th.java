package modele;
/**
 * This class to stock the prop7th.
 * It inherits the class Observable.
 * 
 *
 */
public class Prop7th extends Observable{
	public static Prop p7;
	/**
	 * The constructor.
	 */
	public Prop7th() {
		Prop7th.p7=new Prop();
		
	}
	/**
	 * Flip the prop7th to see what it is.
	 * And to notify the Obsrvers.
	 */
	public void lookProp7th() {
		Prop7th.p7.setMark(true);
		this.setChanged();
		this.notifyObservers(p7);
	}
	/**
	 * Flip back the prop7th.
	 * And to notify the Obsrvers. 
	 */
	public void backProp7th() {
		Prop7th.p7.setMark(false);
		this.setChanged();
		this.notifyObservers(p7);
	}
}
