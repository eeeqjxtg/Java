package modele;
/**
 * This the enum of the name of the prop.
 * 
 *
 */
public enum PropCard {
	The_Lettuce,
	Carrots,
	The_Hat,
	The_Rabbit,
	The_Other_Rabbit,
}
