package modele;

public interface VirtualStrategy {
	/**
	 * To choose the trick of the TrickDeck or TrickPile which will be performed.
	 * 
	 * @param trickdeck is the list to stock trick.
	 * @param trickpile is the list to stock trick.
	 * @param i is which chosen list, 1=TrickDeck, 2=TrickPile.
	 * @return is the chosen trick.
	 */
	public Trick chooseTrick(TrickDeck trickdeck, TrickPile trickpile,int i);
	/**
	 * Swap the prop with player p.
	 * 
	 * @param p is the player who you want to swap your prop.
	 * @param a is your prop which you want to swap. 1=left prop, 2=right prop.
	 * @param b is player p's prop which you want to swap. 1=left prop, 2=right prop.
	 */
	public void swapProp(Player p,int a, int b);
	/**
	 * Rearrange your props with prop7th.
	 * 
	 * @param newleft the new left prop. 1=your original left prop, 2=your original right prop, 7=prop7th.
	 * @param newright the new right prop. 1=your original left prop, 2=your original right prop, 7=prop7th.
	 * @param prop7th the original prop7th.
	 */
	public void rearrange(int newleft, int newright,Prop7th prop7th);
	/**
	 * Filp one of your prop. If all your prop have been flipped,
	 * there will be nothing happened.
	 * 
	 * @param p if the number of the prop which you want to flip. 1=left prop, 2=right prop.
	 */
	public void flipProp(int p);
	/**
	 * Perform the chosen trick.
	 * 
	 * @param t is the chosen trick.
	 * @param trickdeck is the list to stock trick.
	 * @param trickpile is the list to stock trick.
	 * @param prop7th is to stock a prop7th.
	 * @return whether the performance is success. true or false.
	 */
	public boolean performTrick(Trick t, TrickDeck trickdeck, TrickPile trickpile, Prop7th prop7th);
}
