package modele;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
/**
 * This class create all the tricks and stock them in the TrickDeck.
 * 
 *
 */
public class TrickDeck extends Observable{
	public static List<Trick> td;
	/**
	 * Constructor will create a new list to stock the tricks, creates all the tricks,
	 * shuffles tricks and add the The other Hat Tick in the last position.
	 */
	public TrickDeck() {
		TrickDeck.td = new ArrayList<Trick>();
		TrickDeck.td.addAll(createTrick());
		shuffleTrick(TrickDeck.td);
		TrickDeck.td.add(0, new Trick("The_Hat", "The_Other_Rabbit", 6,"The_Other_Hat_Trick"));
	}
	

	/**
	 * The operation creates all the tricks expect the other hat trick.
	 * 
	 * @return a list which stocks all the tricks.
	 */
	public List<Trick> createTrick() {
		List<Trick> list = new ArrayList<Trick>();
		list.add(new Trick("The_Hat", "Carrots", 3,"The_Carrot_Hat_Trick"));
		list.add(new Trick("Carrots", "The_Lettuce", 3,"The_Vegetable_Patch"));
		list.add(new Trick("Carrots", "Carrots", 2,"The_Bunch_of_Carrots"));
		list.add(new Trick("The_Rabbit", "The_Other_Rabbit", 5,"The_Pair_of_Rabbits"));
		list.add(new Trick("The_Hat", "The_Rabbit", 5,"The_Hat_Trick"));
		
		list.add(new Trick("The_Rabbit", "The_Other_Rabbit", "The_Lettuce", 4,"The_Rabbit_That_Didn't_Like_Carrots"));
		list.add(new Trick("The_Hat", "The_Lettuce", "Carrots", 2,"The_Vegetable_Hat_Trick"));
		list.add(new Trick("The_Hat", "The_Rabbit", "The_Other_Rabbit", 4,"The_Slightly_Easier_Hat_Trick"));
		list.add(new Trick("The_Rabbit", "The_Other_Rabbit", "Carrots", "The_Lettuce",1,"The_Hungry_Rabbit"));
		return list;
	}
	/**
	 * Shuffle the trick.
	 * 
	 * @param trickdeck is the list to stock all the tricks.
	 */
	public void shuffleTrick (List<Trick> trickdeck) {
		Collections.shuffle(trickdeck);
	}
	/**
	 * If the trick deck is empty, it will notify the observers.
	 */
	public void setEmpty() {
		this.setChanged();
		this.notifyObservers("setEmpty");
	}
}
