package modele;
/**
 * This class inherits the class Observable
 * 
 *
 */
public class Prop extends Observable{
	private PropCard propcard;
	 private boolean mark;
	 /**
	  * The constructor with parameter.
	  * 
	  * @param propcard is the name of the prop.
	  * @param m is the mark whether the prop has been flipped.
	  */
	 public Prop(PropCard propcard, boolean m) {
		 this.propcard=propcard;
		 this.mark=m;
	 }
	 /**
	  * The constructor without parameter.
	  */
	 public Prop() {
		 this.propcard = null;
		 this.mark = false;
	 }
	 /**
	  * To know the name of the prop.
	  * 
	  * @return the name of the prop.
	  */
	 public String getName () { 
			 String s= String.valueOf(this.propcard);
			 return s;
	 }
	 /**
	  * To know the PropCard of the prop.
	  * 
	  * @return the PropCard
	  */
	 public PropCard getPropCard() {
		 return this.propcard;
	 }
	/**
	 * To whether the prop has been flipped.
	 * 
	 * @return true=flipped, false=not flipped.
	 */
	public boolean getMark() { return this.mark; }
	/**
	 * Set the mark.
	 * 
	 * @param a the situation actual of the prop.
	 */
	public void setMark(boolean a) {
	    this.mark=a;
	    	
	}
		

}
