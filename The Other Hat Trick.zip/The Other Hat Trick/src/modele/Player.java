package modele;

/**
 * This is the father class of all the player which
 * inherit the class Observable and implements the class Comparable.
 * 
 *
 */
public abstract class Player extends Observable implements Comparable<Player>{
	private int age=0;
	private Prop propleft;
	private Prop propright;
	private int nbFail=0;
	private int score=0;
	/**
	 * This is the constructor without parameter.
	 */
	public Player() {
		this.propleft = null;
		this.propright = null;
	}
	/**
	 * This is the constructor with parameter age.
	 * 
	 * @param is the age of the player.
	 */
	public Player(int a) {
		this.propleft = null;
		this.propright = null;
		this.age=a;
	}
	/**
	 * To know what the plyaer's left prop.
	 * 
	 * @return player's left prop.
	 */
	public Prop getPropleft() {
		return this.propleft;
	}
	/**
	 * To know what the plyaer's right prop.
	 * 
	 * @return player's right prop.
	 */
	public Prop getPropright() {
		return this.propright;
	}
	/**
	 * To know the times failed.
	 * 
	 * @return the times failed.
	 */
	public int getnbFail() {
		return this.nbFail;
	}
	/**
	 * Plus one to the times failed.
	 */
	public void setnbFail() {
		this.nbFail++;
	}
	/**
	 * Empty the times failed.
	 */
	public void emptynbFail() {
		this.nbFail=0;
	}
	/**
	 * To know what the player's score is.
	 * 
	 * @return the player's score
	 */
	public int getScore() {
		return this.score;
	}
	/**
	 * When the player succeeded in one turn, 
	 * it will add the score of the trick to his original score.
	 * 
	 * @param i is the score of the trick which the player succeeded.
	 */
	public void setScore(int i) {
		this.score+=i;
		this.setChanged();
		this.notifyObservers("score");
	}
	
	/**
	 * To set the left prop to a new prop p1.
	 * 
	 * @param p1 is the new left prop.
	 */
	public void setPropleft(Prop p1) {
		this.propleft=p1;
	}
	/**
	 * To set the right prop to a new prop p1.
	 * 
	 * @param p1 is the new right prop.
	 */
	public void setPropright(Prop p2) {
		this.propright=p2;
	}
	/**
	 * To know the age of the player.
	 * 
	 * @return the age of the player.
	 */
	public int getAge() {
		return this.age;
	}
	/**
	 * Rewriter the operation compareTo in the interface Comparable.
	 * 
	 * @return is the difference of the age of the two players.
	 */
	public int compareTo(Player o) {
		int i=this.getAge()-o.getAge();
		return i;
	}
	
	/**
	 * To choose the trick of the TrickDeck or TrickPile which will be performed.
	 * If he succeeds, he will take the trick and use the operation rearrange().
	 * If he failed, it will use the opearion flipProp().
	 * 
	 * @param trickdeck is the list to stock trick.
	 * @param trickpile is the list to stock trick.
	 * @param i is which chosen list, 1=TrickDeck, 2=TrickPile.
	 * @return is the chosen trick.
	 */
	public abstract Trick chooseTrick(TrickDeck trickdeck, TrickPile trickpile,int i);
	/**
	 * Swap the prop with player p.
	 * 
	 * @param p is the player who you want to swap your prop.
	 * @param a is your prop which you want to swap. 1=left prop, 2=right prop.
	 * @param b is player p's prop which you want to swap. 1=left prop, 2=right prop.
	 */
	public abstract void swapProp(Player p,int a, int b);
	/**
	 * Rearrange your props with prop7th.
	 * 
	 * @param newleft the new left prop. 1=your original left prop, 2=your original right prop, 7=prop7th.
	 * @param newright the new right prop. 1=your original left prop, 2=your original right prop, 7=prop7th.
	 * @param prop7th the original prop7th.
	 */
	public abstract void rearrange(int newleft, int newright,Prop7th prop7th);
	/**
	 * Filp one of your prop. If all your prop have been flipped,
	 * there will be nothing happened.
	 * 
	 * @param p if the number of the prop which you want to flip. 1=left prop, 2=right prop.
	 */
	public abstract void flipProp(int p);
	/**
	 * Perform the chosen trick.
	 * 
	 * @param t is the chosen trick.
	 * @param trickdeck is the list to stock trick.
	 * @param trickpile is the list to stock trick.
	 * @param prop7th is to stock a prop7th.
	 * @return whether the performance is success. true or false.
	 */
	public abstract boolean performTrick(Trick t, TrickDeck trickdeck, TrickPile trickpile, Prop7th prop7th);
}

