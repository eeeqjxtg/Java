package modele;
import java.util.*;
/**
 * This class has the basic operation of a Trick.
 * 
 *
 */
public class Trick {
	private List<String> trick1 = new ArrayList<String>();
	private List<String> trick2 = new ArrayList<String>();
	private String name;
	private int point;
	public int failtime = 0;
	/**
	 * Constructor without parameter.
	 */
	public Trick() {}
	/**
	 * Constructor of the trick which has one left prop and one right prop.
	 * 
	 * @param p1 the name of the trick's left prop.
	 * @param p2 the name of the trick's right prop.
	 * @param point the score of the trick.
	 * @param name the name of the trick.
	 */
	public Trick(String p1,String p2,int point, String name) {
		this.trick1.add(p1) ;
		this.trick2.add(p2) ;
		this.name = name;
		this.point = point;
	}
	/**
	 * Constructor of the trick which has one left prop and two right prop
	 * or two left prop and one right prop.
	 * 
	 * @param p1 the name of the trick's prop.
	 * @param p2 the name of the trick's prop.
	 * @param p3 the name of the trick's prop.
	 * @param point the score of the trick.
	 * @param name the name of the trick.
	 */
	public Trick(String p1,String p2, String p3,int point, String name) {
		if(point ==2 || name == "The Slightly Easier Hat Trick") {
		this.trick1.add(p1) ;
		this.trick2.add(p2) ;		
		this.trick2.add(p3) ;}
		else {
			this.trick1.add(p1) ;
			this.trick1.add(p2) ;		
			this.trick2.add(p3) ;}
		this.name = name;
		this.point = point;
	}
	/**
	 * Constructor of the trick which has two left prop and two right prop. 
	 * 
	 * @param p11 the name of the trick's left prop.
	 * @param p12 the name of the trick's left prop.
	 * @param p21 the name of the trick's right prop.
	 * @param p22 the name of the trick's right prop.
	 * @param point the score of the trick.
	 * @param name the name of the trick.
	 */
	public Trick(String p11,String p12,String p21, String p22, int point, String name) {
		this.trick1.add(p11) ;
		this.trick1.add(p12) ;
		this.trick2.add(p21) ;
		this.trick1.add(p22) ;
		this.name = name;
		this.point = point;
	}
	/**
	 * To know the score of the trick.
	 * 
	 * @return the score of the trick.
	 */
	public int getPoint() { return this.point;}
	/**
	 * To know the name of the trick.
	 * 
	 * @return the name of the trick.
	 */
	public String getName()  { return this.name;}
	/**
	 * To know which prop in the trick's left.
	 * 
	 * @return the list of the trick's left prop.
	 */
	public List<String> getProp1() { return this.trick1;}
	/**
	 * To know which prop in the trick's right.
	 * 
	 * @return the list of the trick's right prop.
	 */
	public List<String> getProp2() { return this.trick2;} 
	/**
	 * Print the trick's left prop.
	 * 
	 * @return the name of the trick's left prop.
	 */
    public  String toString1() {
    	return this.trick1.toString();
    }
    /**
	 * Print the trick's right prop.
	 * 
	 * @return the name of the trick's right prop.
	 */
    public String toString2() {
    	return this.trick2.toString();
    }
    /**
     * Copy the trick.
     * 
     * @param t the trick which you want to copy.
     */
    public void copy(Trick t) {
    	this.trick1=new ArrayList<String>();
    	for(String str:t.getProp1()) {
    		this.trick1.add(str);
    	}
    	this.trick2=new ArrayList<String>();
    	for(String str:t.getProp2()) {
    		this.trick2.add(str);
    	}
    	this.name=t.getName();
    	this.point=t.getPoint();
    	this.failtime=t.failtime;
    	
    }
    
}
