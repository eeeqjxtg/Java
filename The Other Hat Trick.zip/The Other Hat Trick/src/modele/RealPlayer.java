package modele;
/**
 * Class RealPlayer inherits the class Player.
 * 
 *
 */
public class RealPlayer extends Player{
	/**
	 * This is the constructor without parameter.
	 */
	public RealPlayer() {
		super();
	}
	/**
	 * This is the constructor with parameter age.
	 * 
	 * @param is the age of the player.
	 */
	public RealPlayer(int a) {
		super(a);
	}
	
	/**
	 * Swap the prop with player p.
	 * 
	 * @param p is the player who you want to swap your prop.
	 * @param a is your prop which you want to swap. 1=left prop, 2=right prop.
	 * @param b is player p's prop which you want to swap. 1=left prop, 2=right prop.
	 */
	public synchronized void swapProp(Player p,int a, int b) { 
		if(a==1&&b==1){
			Prop pr = new Prop();
			pr=this.getPropleft();
			this.setPropleft(p.getPropleft());
			p.setPropleft(pr);
		}
		if(a==2&&b==1) {
			Prop pr = new Prop();
			pr=this.getPropleft();
			this.setPropleft(p.getPropright());
			p.setPropright(pr);
		}
		if(a==1&&b==2) {
			Prop pr = new Prop();
			pr=this.getPropright();
			this.setPropright(p.getPropleft());
			p.setPropleft(pr);
		}
		if(a==2&&b==2) {
			Prop pr = new Prop();
			pr=this.getPropright();
			this.setPropright(p.getPropright());
			p.setPropright(pr);
		}
		this.setChanged();
		this.notifyObservers("swapped");
		p.setChanged();
		p.notifyObservers("Prop");
		
	}
		
		
	/**
	 * Rearrange your props with prop7th.
	 * 
	 * @param newleft the new left prop. 1=your original left prop, 2=your original right prop, 7=prop7th.
	 * @param newright the new right prop. 1=your original left prop, 2=your original right prop, 7=prop7th.
	 * @param prop7th the original prop7th.
	 */
	public synchronized void rearrange(int newleft, int newright,Prop7th prop7th) {
		Prop pr = new Prop();
		if(newleft==7&&newright==2) {
			pr=this.getPropleft();
			this.setPropleft(Prop7th.p7);
			Prop7th.p7=pr;
		}
		else if(newleft==1&&newright==7) {
			pr=this.getPropright();
			this.setPropright(Prop7th.p7);
			Prop7th.p7=pr;
		}
		this.getPropleft().setMark(false);
		this.getPropright().setMark(false);
		this.setChanged();
		this.notifyObservers("rearranged");
		prop7th.backProp7th();
	}
	/**
	 * Filp one of your prop. If all your prop have been flipped,
	 * there will be nothing happened.
	 * 
	 * @param p if the number of the prop which you want to flip. 1=left prop, 2=right prop.
	 */
	public synchronized void flipProp(int p) {
		if(p==1) {
			if(this.getPropleft().getMark()==false) {
				this.getPropleft().setMark(true);
			}	
			else {
				this.getPropleft().setMark(false);
			}
		}
		if(p==2) {
			if(this.getPropright().getMark()==false) {
				this.getPropright().setMark(true);
			}
			else {
				this.getPropright().setMark(true);
			}
		}
		this.setChanged();
		this.notifyObservers("flipped");
	}
	/**
	 * Perform the chosen trick.
	 * 
	 * @param t is the chosen trick.
	 * @param trickdeck is the list to stock trick.
	 * @param trickpile is the list to stock trick.
	 * @param prop7th is to stock a prop7th.
	 * @return whether the performance is success. true or false.
	 */
	public boolean performTrick(Trick t, TrickDeck trickdeck, TrickPile trickpile, Prop7th prop7th) {
		boolean p = false;
		
		for(String x:t.getProp1()){
			for(String y:t.getProp2()) {
				if(((this.getPropleft().getName()==x)&&(this.getPropright().getName()==y))||((this.getPropleft().getName()==y)&&(this.getPropright().getName()==x))) {
					p = true;
					break;
				}
			}
			if(p==true)
				break;
		}
		
		if(p==true) {
			this.setScore(t.getPoint());
			trickpile.removeTrick(TrickPile.tp.get(TrickPile.tp.size()-1));
			if(TrickPile.tp.size()==0&&TrickDeck.td.size()!=0) {
				trickpile.addTrick(TrickDeck.td.get(TrickDeck.td.size()-1));
				TrickDeck.td.remove(TrickDeck.td.size()-1);
			}
			this.getPropleft().setMark(true);
			this.getPropright().setMark(true);
			this.setChanged();
			this.notifyObservers("success");
			prop7th.lookProp7th();
			
			return true;
			
		}
		else {
			this.setChanged();
			this.notifyObservers("fail");
			this.setnbFail();
			t.failtime++;
			return false;
		}
	}
	/**
	 * To choose the trick of the TrickDeck or TrickPile which will be performed.
	 * 
	 * @param trickdeck is the list to stock trick.
	 * @param trickpile is the list to stock trick.
	 * @param i is which chosen list, 1=TrickDeck, 2=TrickPile.
	 * @return is the chosen trick.
	 */
	public Trick chooseTrick(TrickDeck trickdeck, TrickPile trickpile,int i) {//i=1trickdeck,i=2trickpile
		Trick t=new Trick();
		if(TrickDeck.td.size()!=0&&i==1) {
			trickpile.addTrick(TrickDeck.td.get(TrickDeck.td.size()-1));
			TrickDeck.td.remove(TrickDeck.td.size()-1);
			if(TrickDeck.td.size()==0) {
				trickdeck.setEmpty();
			}
			t=TrickPile.tp.get(TrickPile.tp.size()-1);
			return t;
		}
		else {
			if(TrickDeck.td.size()==0) {
				int a=1;
				this.setChanged();
				this.notifyObservers(a);
			}
			t=TrickPile.tp.get(TrickPile.tp.size()-1);
			return t;
		}
		
	}
	
	
	

}
