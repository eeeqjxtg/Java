package modele;
import java.util.*;
/**
 * Class VirualPlayer inherits the class Player and 
 * implements the interface VirtualStrategy.
 * This is the hard mode.
 * 
 *
 */
public class VirtualPlayerHard extends Player implements VirtualStrategy{
	/**
	 * Constructor of the class VirtualPlayerHard whose age is also 100.
	 * He is always older than RealPlayer.
	 */
	public VirtualPlayerHard() {
		super(100);
	}
	/**
	 * We use the way of Random, so he will swap prop randomly.
	 */
	public synchronized void swapProp(Player p,int a, int b) {
		Prop pr = new Prop();
		Random radom = new Random();
		int r = radom.nextInt(2);
		if(r==0) {
		pr=this.getPropleft();
		this.setPropleft(p.getPropleft());
		p.setPropleft(pr);
		}
		if(r==1) {
		 pr=this.getPropright();
		 this.setPropright(p.getPropright());
		 p.setPropright(pr);
		}
		this.setChanged();
		this.notifyObservers("Prop");
		p.setChanged();
		p.notifyObservers("Prop");
	}
	/**
	 * We use the way of Random, so he will rearrange his props randomly.
	 */
	public synchronized void rearrange(int newleft, int newright,Prop7th prop7th) {
		Prop pr = new Prop();
		Random random = new Random();
		int r = random.nextInt(2);
		if(r==0) {
		   pr=this.getPropleft();
		   this.setPropleft(Prop7th.p7);
		   Prop7th.p7=pr;
		}
		if(r==1) {
			pr=this.getPropright();
			this.setPropright(Prop7th.p7);
			Prop7th.p7=pr;
		} 
		this.getPropleft().setMark(false);
		this.getPropright().setMark(false);
		this.setChanged();
		this.notifyObservers("Prop");
		prop7th.backProp7th();
	}
	/**
	 * We use the way of Random, so he will flip his prop randomly.
	 */
	public synchronized void flipProp(int p) {
		if(this.getPropleft().getMark()==true) {
			if(this.getPropright().getMark()==true)
				this.getPropleft().setMark(false);
			else
				this.getPropright().setMark(true);
		}
		else
			this.getPropleft().setMark(true);
		this.setChanged();
		this.notifyObservers("flipped");
	}
	/**
	 * Perform the chosen trick.
	 * If he succeeds, he will take the trick and use the operation rearrange().
	 * If he failed, it will use the opearion flipProp().
	 * 
	 * @param t is the chosen trick.
	 * @param trickdeck is the list to stock trick.
	 * @param trickpile is the list to stock trick.
	 * @param prop7th is to stock a prop7th.
	 * @return whether the performance is success. true or false.
	 */
	public boolean performTrick(Trick t, TrickDeck trickdeck, TrickPile trickpile, Prop7th prop7th) {
		boolean p = false;
		
		for(String x:t.getProp1()){
			for(String y:t.getProp2()) {
				if(((this.getPropleft().getName()==x)&&(this.getPropright().getName()==y))||((this.getPropleft().getName()==y)&&(this.getPropright().getName()==x))) {
					p = true;
					break;
				}
			}
			if(p==true)
				break;
		}
		
		if(p==true) {
			this.setScore(t.getPoint());
			trickpile.removeTrick(TrickPile.tp.get(TrickPile.tp.size()-1));
			if(TrickPile.tp.size()==0&&TrickDeck.td.size()!=0) {
				trickpile.addTrick(TrickDeck.td.get(TrickDeck.td.size()-1));
				TrickDeck.td.remove(TrickDeck.td.size()-1);
			}
			this.getPropleft().setMark(true);
			this.getPropright().setMark(true);
			this.setChanged();
			this.notifyObservers("AIsuccess");
			prop7th.lookProp7th();
			
			return true;
			
		}
		else {
			this.setnbFail();
			t.failtime ++;
			this.setChanged();
			this.notifyObservers("AIfail"); 
			return false;
		}
		
	}
	/**
	 * We use the way of Random, so he will choose trick randomly.
	 * But when the TricjDeck is empty, he will choose the TrickPile.
	 */
	public synchronized Trick chooseTrick(TrickDeck trickdeck, TrickPile trickpile,int i) {
		Trick tr=new Trick();
		if(TrickDeck.td.size()!=0) {
			trickpile.addTrick(TrickDeck.td.get(TrickDeck.td.size()-1));
			TrickDeck.td.remove(TrickDeck.td.size()-1);
			if(TrickDeck.td.size()==0) {
				trickdeck.setEmpty();
			}
			tr=TrickPile.tp.get(TrickPile.tp.size()-1);
			return tr;
		}
		else {
			tr=TrickPile.tp.get(TrickPile.tp.size()-1);
			return tr;
		}
	}
	
	
}
