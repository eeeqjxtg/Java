package controleur;
import javax.swing.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import modele.PartieDeJeu;
import vue.*;
/**
 * This is the controller of the first frame of the graphical interface. This
 * class is used to initialize the number of real players, their ages
 * and hard mode or easy mode.
 *
 */
public class ControleurStarteGame {
	private MonInterface moninterface;
	private PartieDeJeu partiedejeu;
	private JButton startgame;
	private JCheckBox cPlayer_1;
	private JCheckBox cPlayer_2;
	private JCheckBox cPlayer_3;
	private JCheckBox cEasy;
	private JCheckBox cHard;
	private JTextField[] tAs=new JTextField[3];
	private int[] tAges=new int[3];
	private int a=0;
	private char b;
	/**
	 * This is the constructor.
	 * 
	 * @param window instance of the class "VueTexte"
	 * @param partie instance of the class "PartieDeJeu"
	 * @param button the button of "Start Game"
	 * @param f1     the first frame
	 * @param f2     the second frame
	 * @param cP_1   the check box of one real player
	 * @param cP_2   the check box of two real players
	 * @param cP_3   the check box of three real players
	 * @param ceasy  the check box of easy mode
	 * @param chard  the check box of hard mode
	 * @param tAge_1 the age of the first player
	 * @param tAge_2 the age of the second player
	 * @param tAge_3 the age of the third player
	 */
	public ControleurStarteGame(MonInterface window,PartieDeJeu partie, JButton button,JFrame f1, JFrame f2,JCheckBox cP_1,
			JCheckBox cP_2, JCheckBox cP_3,JCheckBox ceasy,JCheckBox chard,JTextField tAge_1,JTextField tAge_2,JTextField tAge_3) {
		moninterface=window;
		partiedejeu=partie;
		startgame=button;
		cPlayer_1 = cP_1;
		cPlayer_2= cP_2;
		cPlayer_3 = cP_3;
		this.cEasy = ceasy;
		this.cHard = chard;
		this.tAs[0]=tAge_1;
		this.tAs[1]=tAge_2;
		this.tAs[2]=tAge_3;
		
		JFrame frame1 = f1;
		JFrame frame2 = f2;
		/**
		 * They are event listeners. They are used to get the number of real player
		 * according to the selected check box.
		 * 
		 * @param a the number of real player
		 */
        cPlayer_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		if(cPlayer_1.isSelected())
        			a=1; 
        	}
        });
        cPlayer_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		if(cPlayer_2.isSelected())
        			a=2;
        	}
        });
        cPlayer_3.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		if(cPlayer_3.isSelected())
        			a=3;
        	}
        });
        /**
		 * They are event listeners. They are used to get real players' ages.
		 * 
		 * @param tAges is a array to store the ages.
		 */
        tAs[0].addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		tAges[0]=Integer.parseInt(tAs[0].getText().trim());
        	}
        });
        tAs[1].addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		tAges[1]=Integer.parseInt(tAs[1].getText().trim());
        	}
        });
        tAs[2].addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		tAges[2]=Integer.parseInt(tAs[2].getText().trim());
        	}
        });
        /**
		 * They are event listeners. They are used to get the source: which mode is
		 * selected.
		 * 
		 * @param b is a char to store the mode : 'e' is easy mode, 'h' is hard mode.
		 */
        cEasy.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		if(cEasy.isSelected())
        			b='e';
        	}
        });
        
        cHard.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		if(cHard.isSelected()) {
        			b='h';
        		}
        		
        	}
        });
        /**
		 * This event listener is used to get the signal of starting game. After
		 * clicking the button, set the first window to be invisible and set the second
		 * window to be visible, add the graphical interface to the observer of the
		 * instance of "PartieDeJeu", create the interface of text and start the thread
		 * of the text page.
		 */
		startgame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				partiedejeu.preparePlayer(a, b, tAges);
			    frame1.setVisible(false);
			    frame2.setVisible(true);
			    for(int i=0;i<PartieDeJeu.playerlist.size();i++) {
					PartieDeJeu.playerlist.get(i).addObserver(moninterface);
				
				}
			    VueTexte maConsoleText = new VueTexte(partiedejeu);
				Thread t = new Thread(maConsoleText);
				t.start();
			}
		});
	}
}