package controleur;
import javax.swing.*;
import java.util.*;
import java.awt.event.*;
import modele.*;
/**
 * Class ControleurFrame2 is the controller of the second frame of graphical interface.
 *
 */
public class ControleurFrame2 {
	private PartieDeJeu partie;
    private JButton btnTd;
    private JButton btnTp;
    private JButton prop7;
    private JButton btnProp_1;
    private JButton btnProp_2;
    private JButton btnProp_3;
    private JButton btnProp_4;
    private JButton btnProp_5;
    private JButton btnProp_6;
    private JButton btnNext;
    private JButton btnSwap;
    private JButton btnFlip;
    private JButton btnRearrange;
    private JTextField textField;
    private JTextField textField_1;
    
    private boolean swapping = false;
    private boolean flipping = false;
    private boolean rearranging = false;
    private boolean success=false;
    
    private Trick choosetrick=new Trick();
    
    private int propChosen = 0;
    private int playerChosen = 0;
    private ArrayList<Integer> temporary = new ArrayList<Integer>();

    /**
	 * This is the constructor of this class. The buttons of this class are event
	 * listeners.
	 * 
	 * @param partiedejeu     instance of the class "PartieDeJeu"
	 * @param buttonTd        button of trick deck
	 * @param buttonTp        button of trick pile
	 * @param p7              button of the 7th prop
	 * @param buttonProp_1    the left prop of the player number 1
	 * @param buttonProp_2    the right prop of the player number 1
	 * @param buttonProp_3    the left prop of the player number 2
	 * @param buttonProp_4    the right prop of the player number 2
	 * @param buttonProp_5    the left prop of the player number 0
	 * @param buttonProp_6    the right prop of the player number 0
	 * @param buttonNext      button of "Next" : turn to next player
	 * @param buttonSwap      button of "Swap" : swap prop
	 * @param buttonFlip      button of "Flip" : flip prop
	 * @param buttonRearrange button of "Rearrange" : rearrange prop
	 * @param textfield       the first text field is used to tell the player what
	 *                        to do next
	 * @param textfield_1     the second text field is used to Tell the player the
	 *                        prop that he currently has
	 */
    public ControleurFrame2(PartieDeJeu partiedejeu,JButton buttonTd,JButton buttonTp,JButton p7,JButton buttonProp_1,JButton buttonProp_2,JButton buttonProp_3,JButton buttonProp_4,JButton buttonProp_5,JButton buttonProp_6,JButton buttonNext,JButton buttonSwap,JButton buttonFlip,JButton buttonRearrange,JTextField textfield,JTextField textfield_1) {
    	this.partie = partiedejeu;
    	this.btnTd = buttonTd;
    	this.btnTp = buttonTp;
    	this.prop7 = p7;
    	this.btnProp_1 = buttonProp_1;
    	this.btnProp_2 = buttonProp_2;
    	this.btnProp_3 = buttonProp_3;
    	this.btnProp_4 = buttonProp_4;
    	this.btnProp_5 = buttonProp_5;
    	this.btnProp_6 = buttonProp_6;
    	this.btnNext = buttonNext;
    	this.btnSwap=buttonSwap;
    	this.btnFlip=buttonFlip;
    	this.btnRearrange=buttonRearrange;
    	this.textField=textfield;
    	this.textField_1=textfield_1;
    	
    	btnProp_1.setActionCommand("1");
    	btnProp_2.setActionCommand("2");
    	btnProp_3.setActionCommand("3");
    	btnProp_4.setActionCommand("4");
    	btnProp_5.setActionCommand("5");
    	btnProp_6.setActionCommand("6");
    	/**
		 * Show the chosen trick and tell the player what to do next.
		 * 
		 * After choosing trick deck or trick pile, the screen will show the chosen
		 * trick and tell the player what props he has and tell him what to do next.
		 */
    	btnTd.addActionListener(new ActionListener() {
           	public void actionPerformed(ActionEvent e) {
           		choosetrick=PartieDeJeu.playerlist.get(partie.numcourrent).chooseTrick(partie.trickdeck, partie.trickpile, 1);
           		textField.setText("Click Swap");
           		textField_1.setText("LeftProp is "+PartieDeJeu.playerlist.get(partie.numcourrent).getPropleft().getName()+", RightProp is "+PartieDeJeu.playerlist.get(partie.numcourrent).getPropright().getName());
           		
           	}
           });
    	 
    	 btnTp.addActionListener(new ActionListener() {
           	public void actionPerformed(ActionEvent e) {
           		choosetrick=PartieDeJeu.playerlist.get(partie.numcourrent).chooseTrick(partie.trickdeck, partie.trickpile, 2);
           		textField.setText("Click Swap");
           		textField_1.setText("LeftProp is "+PartieDeJeu.playerlist.get(partie.numcourrent).getPropleft().getName()+", RightProp is "+PartieDeJeu.playerlist.get(partie.numcourrent).getPropright().getName());
           		
           	}
           });
    	 /**
 		 * The actions about the 7th prop after clicking the button "rearrange".
 		 * 
 		 * When player is rearranging prop, if the arraylist "temporary" is empty, it
 		 * will wait the player to choose another one, if "temporary" is not empty, it
 		 * will call the function of the rearranging props and all the six props are set
 		 * enabled.
 		 * 
 		 * @param temporary is an arraylist to store the props that player want to leave
 		 */
    	 prop7.addActionListener(new ActionListener() {
           	public void actionPerformed(ActionEvent e) {
           		if(rearranging) {
    		    	if( temporary.size()>0) {
    		    		PartieDeJeu.playerlist.get(partie.numcourrent).rearrange(temporary.get(0), 7, partie.prop7th);
    		    	    rearranging = false;
    		    	    temporary.clear();
    		    	    btnProp_1.setEnabled(true);
    	       	    	   btnProp_2.setEnabled(true);
    	       	    	   btnProp_3.setEnabled(true);
    	       	    	   btnProp_4.setEnabled(true);
    	       	    	   btnProp_5.setEnabled(true);
    	       	    	   btnProp_6.setEnabled(true);
    	       	    	textField.setText("Click NextPlayer");
    		    	    
    		    	}    
    		    	else {
    		    	     temporary.add(7);
    		    	     textField.setText("Click another Prop");
    		    	}
    		    }
           	}
           });
    	
    	 /**
 		 * The actions after a prop is clicked.
 		 * 
 		 * It will call the function "PropAction" after one of six props is clicked.
 		 */
    	 btnProp_1.addActionListener(new ActionListener() {
          	public void actionPerformed(ActionEvent e) {
          		PropAction(e);
          	
          	}
          });
    	 
    	 
    	 btnProp_2.addActionListener(new ActionListener() {
          	public void actionPerformed(ActionEvent e) {
          		PropAction(e);
          		
          	}
          });
    	 
    	 btnProp_3.addActionListener(new ActionListener() {
           	public void actionPerformed(ActionEvent e) {
           		PropAction(e);
          		
           	}
           });
    	 
    	 btnProp_4.addActionListener(new ActionListener() {
           	public void actionPerformed(ActionEvent e) {
           		PropAction(e);
           	}
           });
    	 
    	 btnProp_5.addActionListener(new ActionListener() {
           	public void actionPerformed(ActionEvent e) {
           		PropAction(e);
           	}
           });
    	 
    	 btnProp_6.addActionListener(new ActionListener() {
           	public void actionPerformed(ActionEvent e) {
           		PropAction(e);
           	}
           });
    	 /**
 		 * Get the signal of turning to next player.
 		 * 
 		 * After clicking the button "Next", it will judge whether the game ends or not,
 		 * whether the next player is a real player or a virtual player, so that
 		 * different functions are called and different texts are showed.
 		 */
    	 btnNext.addActionListener(new ActionListener() {
          	public void actionPerformed(ActionEvent e) {
          		partie.numcourrent=(partie.numcourrent+1)%3;
          		if(PartieDeJeu.playerlist.get(partie.numcourrent) instanceof VirtualPlayer||PartieDeJeu.playerlist.get(partie.numcourrent) instanceof VirtualPlayerHard) {
          			textField.setText("Now is VirtualPlayer");
          			choosetrick=PartieDeJeu.playerlist.get(partie.numcourrent).chooseTrick(partie.trickdeck, partie.trickpile, 1);
          			PartieDeJeu.playerlist.get(partie.numcourrent).swapProp(PartieDeJeu.playerlist.get((partie.numcourrent+1)%3), 1, 1);
          			success=PartieDeJeu.playerlist.get(partie.numcourrent).performTrick(choosetrick, partie.trickdeck, partie.trickpile, partie.prop7th);
          			if(success) {
          				textField.setText("Ta-Dah!Click NextPlayer");
          				if(choosetrick.getName()=="The_Other_Hat_Trick"&&success==true) {
     		    		   textField_1.setText("End Game. The winner is Player"+partie.winner1());
     		    		   btnNext.setEnabled(false);
          				}
          				PartieDeJeu.playerlist.get(partie.numcourrent).rearrange(1, 1, partie.prop7th);
          			}
          			else {
          				if(choosetrick.getName()=="The_Other_Hat_Trick"&&success==false&&choosetrick.failtime==3) {
     		    		   textField_1.setText("End Game! The winner is Player"+partie.winner2());
     		    		   btnNext.setEnabled(false);
     	        		}
          				PartieDeJeu.playerlist.get(partie.numcourrent).flipProp(1);
          				textField.setText("Click NextPlayer");
          			}
          		}
          		else if(PartieDeJeu.playerlist.get(partie.numcourrent) instanceof RealPlayer) {
          			textField.setText("Click TrcikDeck or TrickPile");
          			textField_1.setText("Now Your are Player "+partie.numcourrent);
          			partie.nextPlayer();
          		}
        	
          	}
          }
     	 );
    	 
    	 /**
 		 * Get the signal of swapping props.
 		 * 
 		 * Players just can swap props after clicking this button and all of props
 		 * except those of current player are able to be chosen.
 		 * 
 		 * @param swapping is a boolean to know whether the player is swapping props or
 		 *                 not
 		 */
     	 btnSwap.addActionListener(new ActionListener() {
           	public void actionPerformed(ActionEvent e) {
           		swapping = true;
           		
          	    switch(partie.numcourrent) {
          	    case 0:
          	       btnProp_1.setEnabled(true);
        	    	   btnProp_2.setEnabled(true);
        	    	   btnProp_3.setEnabled(true);
        	    	   btnProp_4.setEnabled(true);
        	    	   btnProp_5.setEnabled(false);
        	    	   btnProp_6.setEnabled(false);
        	    	   break;
          	    case 1:
          	    	   btnProp_1.setEnabled(false);
          	    	   btnProp_2.setEnabled(false);
          	    	   btnProp_3.setEnabled(true);
          	    	   btnProp_4.setEnabled(true);
          	    	   btnProp_5.setEnabled(true);
          	    	   btnProp_6.setEnabled(true);
          	    	 break;
          	    case 2:
          	       btnProp_1.setEnabled(true);
        	    	   btnProp_2.setEnabled(true);
        	    	   btnProp_3.setEnabled(false);
        	    	   btnProp_4.setEnabled(false);
        	    	   btnProp_5.setEnabled(true);
        	    	   btnProp_6.setEnabled(true);
        	    	   break;
          	    }        	    
           	}
           });
     	/**
 		 * Get the signal of flipping prop.
 		 * 
 		 * Players just can flip props after clicking this button and just his own props
 		 * are able to be flipped.
 		 * 
 		 * @param flipping is a boolean to know whether the player is swapping props or not.
 		 */
     	 btnFlip.addActionListener(new ActionListener() {
           	public void actionPerformed(ActionEvent e) {
           		flipping = true;
          	    switch(partie.numcourrent) {
          	    case 0:
          	    	   btnProp_1.setEnabled(false);
         	    	   btnProp_2.setEnabled(false);
         	    	   btnProp_3.setEnabled(false);
         	    	   btnProp_4.setEnabled(false);
         	    	   btnProp_5.setEnabled(true);
         	    	   btnProp_6.setEnabled(true);
         	    	  break;
          	    case 1:
          	    	   btnProp_1.setEnabled(true);
          	    	   btnProp_2.setEnabled(true);
          	    	   btnProp_3.setEnabled(false);
          	    	   btnProp_4.setEnabled(false);
          	    	   btnProp_5.setEnabled(false);
          	    	   btnProp_6.setEnabled(false);
          	    	 break;
          	    case 2:
          	           btnProp_1.setEnabled(false);
         	    	   btnProp_2.setEnabled(false);
         	    	   btnProp_3.setEnabled(true);
         	    	   btnProp_4.setEnabled(true);
         	    	   btnProp_5.setEnabled(false);
         	    	   btnProp_6.setEnabled(false);
         	    	  break;
          	    }        	          	    
           	}
           });
     	/**
 		 * Get the signal of rearranging props.
 		 * 
 		 * Players just can rearrange props after clicking this button and only his
 		 * props are able to be rearranged.
 		 * 
 		 * @param rearranging is a boolean to know whether the player is swapping props
 		 *                    or not
 		 */
     	 btnRearrange.addActionListener(new ActionListener() {
           	public void actionPerformed(ActionEvent e) {
           		rearranging = true;
           		switch(partie.numcourrent) {
          	    case 0:
          	    	   btnProp_1.setEnabled(false);
         	    	   btnProp_2.setEnabled(false);
         	    	   btnProp_3.setEnabled(false);
         	    	   btnProp_4.setEnabled(false);
         	    	   btnProp_5.setEnabled(true);
         	    	   btnProp_6.setEnabled(true);
         	    	  break;
          	    case 1:
          	    	   btnProp_1.setEnabled(true);
          	    	   btnProp_2.setEnabled(true);
          	    	   btnProp_3.setEnabled(false);
          	    	   btnProp_4.setEnabled(false);
          	    	   btnProp_5.setEnabled(false);
          	    	   btnProp_6.setEnabled(false);
          	    	 break;
          	    case 2:
          	           btnProp_1.setEnabled(false);
         	    	   btnProp_2.setEnabled(false);
         	    	   btnProp_3.setEnabled(true);
         	    	   btnProp_4.setEnabled(true);
         	    	   btnProp_5.setEnabled(false);
         	    	   btnProp_6.setEnabled(false);
         	    	  break;
          	    }
           	}
           });
    	
    }
    /**
	 * The actions after one prop is clicked.
	 * 
	 * Get the source of this event and get the number of player, and set those
	 * unrelated buttons unable to be chosen. If the number of the player is the
	 * current player, determine which state the player is in : swap props, flip
	 * prop or rearrange props, then according to different state, call different
	 * functions and show different texts.
	 * 
	 * @param num is the number of player who the clicked props belongs to
	 * @param e   the event that the event listener get
	 */
    public void PropAction(ActionEvent e) {
    	int i=Integer.parseInt(e.getActionCommand().trim());
    	int num=0;
    	if(i==1||i==2)
    		num=1;
    	else if(i==3||i==4)
    		num=2;
    	else if(i==5||i==6) {
    		num=0;
    	}
    	int leftright=0;
    	if(i%2==1) 
    		leftright=1;
    	else if(i%2==0)
    		leftright=2;
    	if(partie.numcourrent!=num) {
		   if(swapping) 
			 propChosen = leftright;
		     playerChosen = num;
		     switch(partie.numcourrent) {
       	    case 0:
       	    	   btnProp_1.setEnabled(false);
      	    	   btnProp_2.setEnabled(false);
      	    	   btnProp_3.setEnabled(false);
      	    	   btnProp_4.setEnabled(false);
      	    	   btnProp_5.setEnabled(true);
      	    	   btnProp_6.setEnabled(true);
      	    	   break;
       	    case 1:
       	    	   btnProp_1.setEnabled(true);
       	    	   btnProp_2.setEnabled(true);
       	    	   btnProp_3.setEnabled(false);
       	    	   btnProp_4.setEnabled(false);
       	    	   btnProp_5.setEnabled(false);
       	    	   btnProp_6.setEnabled(false);
       	    	   break;
       	    case 2:
       	           btnProp_1.setEnabled(false);
      	    	   btnProp_2.setEnabled(false);
      	    	   btnProp_3.setEnabled(true);
      	    	   btnProp_4.setEnabled(true);
      	    	   btnProp_5.setEnabled(false);
      	    	   btnProp_6.setEnabled(false);
      	    	   break;
       	    }
		   
	    }
		else{
		    if(swapping) {
		       PartieDeJeu.playerlist.get(partie.numcourrent).swapProp(PartieDeJeu.playerlist.get(playerChosen), propChosen, leftright);//������
		       textField_1.setText("LeftProp is "+PartieDeJeu.playerlist.get(partie.numcourrent).getPropleft().getName()+", RightProp is "+PartieDeJeu.playerlist.get(partie.numcourrent).getPropright().getName());
		       swapping = false;
		       success=PartieDeJeu.playerlist.get(partie.numcourrent).performTrick(choosetrick, partie.trickdeck, partie.trickpile, partie.prop7th);
		       if(success) {
		    	   textField.setText("Ta-Dah! Click Rearrange");
		    	   if(choosetrick.getName()=="The_Other_Hat_Trick"&&success==true) {
		    		   textField_1.setText("End Game. The winner is Player"+partie.winner1());
		    		   this.btnNext.setEnabled(false);
	        		}
		       }
		       else {
		    	   textField.setText("Fail! Click Flip");
		    	   if(choosetrick.getName()=="The_Other_Hat_Trick"&&success==false&&choosetrick.failtime==3) {
		    		   textField_1.setText("End Game! The winner is Player"+partie.winner2());
		    		   this.btnNext.setEnabled(false);
	        		}
		       }  
		    }
		    if(flipping) {
		    	PartieDeJeu.playerlist.get(partie.numcourrent).flipProp(leftright);
		    	flipping = false;
		    	btnProp_1.setEnabled(true);
   	    	   btnProp_2.setEnabled(true);
   	    	   btnProp_3.setEnabled(true);
   	    	   btnProp_4.setEnabled(true);
   	    	   btnProp_5.setEnabled(true);
   	    	   btnProp_6.setEnabled(true);
   	    	   textField.setText("Click NextPlayer");
		    }
		    if(rearranging) {
		    	if( temporary.size()>0) {
		    		PartieDeJeu.playerlist.get(partie.numcourrent).rearrange(temporary.get(0), leftright, partie.prop7th);
		    		textField_1.setText("LeftProp is "+PartieDeJeu.playerlist.get(partie.numcourrent).getPropleft().getName()+", RightProp is "+PartieDeJeu.playerlist.get(partie.numcourrent).getPropright().getName());
		    	    rearranging = false;
		    	    temporary.clear();
		    	    btnProp_1.setEnabled(true);
       	    	   btnProp_2.setEnabled(true);
       	    	   btnProp_3.setEnabled(true);
       	    	   btnProp_4.setEnabled(true);
       	    	   btnProp_5.setEnabled(true);
       	    	   btnProp_6.setEnabled(true);
       	    	textField.setText("Click NextPlayer");
		    	}    
		    	else {
		    	     temporary.add(leftright);
		    	     textField.setText("Click another Prop");
		    	}
		    }
		}
    }
}