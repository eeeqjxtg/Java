package vue;
import modele.Observable;

public interface Observer {
	public void update(Observable instanceObservable, Object o);
}
