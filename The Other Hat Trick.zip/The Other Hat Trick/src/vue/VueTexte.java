package vue;
import java.io.*;
import modele.*;
import modele.Observable;
/**
 * Class VueTexte is responsible for interface of text.
 * 
 * This class implements interface observer and runnable.
 *
 */
public class VueTexte implements Observer, Runnable {
	private PartieDeJeu partie; 
	private boolean gameover = false;
	public int winner;
	public int a;
	public int[] input;
	public Trick trick;
	public boolean success;
	
	/**
	 * The constructor of class Vuetexte.
	 * 
	 * Each player adds this class to their lists of observers.
	 * 
	 * @param monpartie instance of class PartieDeJeu
	 */
	
	public VueTexte(PartieDeJeu monpartie) {
		this.partie=monpartie;	
		partie.trickdeck.addObserver(this);
		partie.trickpile.addObserver(this);
		partie.prop7th.addObserver(this);	
		
		for(int i = 0; i<PartieDeJeu.playerlist.size() ;i++) {
			PartieDeJeu.playerlist.get(i).addObserver(this);
		}
		 
		
	}
	
	/**
	 * Run the game by turn until parametric "gameover" is false.
	 * 
	 * @param gameover is boolean, gameover is true when the game ends.
	 */
	public void run() {
		
		while(!gameover) {
			for(int i=0;i<3;i++) { 
				if(PartieDeJeu.playerlist.get(partie.numcourrent).getAge()==100) {
					  virtualplayer(partie.numcourrent);
					  partie.numcourrent=(partie.numcourrent+1)%3;
				  }else {
					  realplayer(partie.numcourrent);
					  partie.numcourrent=(partie.numcourrent+1)%3;
				  
			  }
		      if(gameover)
		    	  break;
		      
			}
		}
		
	}
	
	/**
	 * Convert the data of type String into data type integer.
	 * 
	 * The input is separated by spaces and the extracted numbers are stored in an
	 * array named input.
	 * 
	 * @return is an array that store the data entered by player.
	 */
	private int[] readInt()  {
		int[] input = new int[3];
		BufferedReader br = new BufferedReader (new InputStreamReader(System.in));
		try {
		String resultat = br.readLine();
		String subArg [] = resultat.split("\\s");  		
		for(int i=0;i<subArg.length;i++)  {
			input[i]=Integer.parseInt(subArg[i]);
			
		} 
		}catch(IOException e) {
		    System.err.println(e.getMessage());
		    
		}
		return input;
			
	}
	 
	/**
	 * Update the text of interface after getting the notifications.
	 * 
	 * According to the information sended by observable instances, print current
	 * information and what the player needs to do next to the console.
	 * 
	 * @param instanceObervable is the instance who has changed and notify all observers.
	 * @param o is the information that the changed instance tell all observers.
	 */
	public void update(Observable instanceObservable, Object o) {
		if(instanceObservable instanceof TrickPile) { 
			if(TrickPile.tp.size()!=0 ) {
				
				System.out.println("------Trickpile now is : ["+TrickPile.tp.get(TrickPile.tp.size()-1).getName()+"]------");
			    if(PartieDeJeu.playerlist.get(partie.numcourrent) instanceof RealPlayer) {
			    System.out.println("------your left prop now is ["+ PartieDeJeu.playerlist.get(partie.numcourrent).getPropleft().getName()+"]------"+"------your right prop now is ["+ PartieDeJeu.playerlist.get(partie.numcourrent).getPropright().getName()+"]------");
			    System.out.println("----Input the number of player you want to swap with     0/1/2");
			    System.out.println("----Input the number of the chosen player's Prop and of your own Prop you want to swap"); 
			    System.out.println("1= left prop ,2 = right prop    ex: 1 espace 1 espace 1");
			    
			    }
			}
			else
				System.out.println("------------ Trickpile now is empty ! ------------");
		}
		
		if(instanceObservable instanceof TrickDeck) {
			if(TrickDeck.td.size()==0)
				System.out.println("------Attention ! Trickdeck is empty now !------");
		}
		
		if(instanceObservable instanceof Prop7th) {
			if(Prop7th.p7.getMark()==true) {
				System.out.println("------Prop7th now is : ["+Prop7th.p7.getName()+"]------");
			}
			if(PartieDeJeu.playerlist.get((partie.numcourrent+1)%3) instanceof RealPlayer) {
				System.out.println("------------Choose TrickDeck or TrickPile ?-------------");
				  System.out.println("------------ 1 = TrickDeck , 2 = TrickPile -------------");
			}
		}
		
		if(instanceObservable instanceof Player) { 
			Player player = (Player) instanceObservable;
			
			if(o.equals("swapped") ||o.equals("rearranged") ) {
				
	            System.out.println("------your left prop now is ["+ player.getPropleft().getName()+"]------"+
	            		           "------your right prop now is ["+ player.getPropright().getName()+"]------");
		    }
			if(o.equals("flipped")) {
				
				if(player.getPropleft().getMark()==true) {
					System.out.println("------Player"+PartieDeJeu.playerlist.indexOf(player)+"'s left prop is flipped [" + player.getPropleft().getName()+"]------");
				}
				if(player.getPropright().getMark()==true) {
					System.out.println("------Player"+PartieDeJeu.playerlist.indexOf(player)+"'s right prop is flipped [" + player.getPropright().getName()+"]------");
				}
				if(PartieDeJeu.playerlist.get((partie.numcourrent+1)%3) instanceof RealPlayer) {
					System.out.println("------------Choose TrickDeck or TrickPile ?-------------");
					  System.out.println("------------ 1 = TrickDeck , 2 = TrickPile -------------");
				}
				
			}
			if(o.equals("score")) {
				System.out.println("------Now Player"+PartieDeJeu.playerlist.indexOf(player)+"'s score is : " + player.getScore()+"------");
			}
			if(o.equals("winner")) {
				System.out.println("");
				System.out.println("------ GAMEOVER ! ------");
				System.out.println("------The winner is "+PartieDeJeu.playerlist.indexOf(player)+" ------");
				System.out.println("His score is : "+ player.getScore()+" ------");
				System.exit(0);
			}
			if(o.equals("success")) {
				System.out.println("------Ta-Dah !------");
				System.out.println("------Now your score is : " + player.getScore()+"------");
				System.out.println("------Now you can rearrange your props------");
				System.out.println("------Input the number of your prop you want to leave------");
				System.out.println("------1 = left prop ,2 = right prop , 7 = the 7th prop   like 1 espace 2 / 1 espace 7 / 7 espace 2------");
			}
			if(o.equals("fail")) {
				System.out.println("------You fail !------");
			    System.out.println("------Now you should flip one of your props------");
				System.out.println("------Input the number of it------");
				System.out.println("------1 = left prop ,2 = right prop  like 1 / 2 ------");
			}
			 if(o.equals("AIsuccess")) {
				   System.out.println("------Ta-Dah ! ------ ");
				   System.out.println("The player's score is : "+ player.getScore());
			   }
			 if(o.equals("AIfail")) {
				   System.out.println("------AI fail ! ------");
			   }
			 
			 if(o instanceof Integer) {
				 System.out.println("------your left prop now is ["+ PartieDeJeu.playerlist.get(partie.numcourrent).getPropleft().getName()+"]------"+"------your right prop now is ["+ PartieDeJeu.playerlist.get(partie.numcourrent).getPropright().getName()+"]------");
				    System.out.println("----Input the number of player you want to swap with     0/1/2");
				    System.out.println("----Input the number of the chosen player's Prop and of your own Prop you want to swap"); 
				    System.out.println("1= left prop ,2 = right prop    ex: 1 espace 1 espace 1");
			 }
		   
		}
	}
	
	
	/**
	 * The actions that real players take each tour.
	 * 
	 * @param i the number of player.
	 */
	public void realplayer(int i) {
		System.out.println();
		  System.out.println("-------------- You are player " + i +" --------------");
	      if(TrickPile.tp.size()==0) {
	    	  System.out.println("------------ Trickpile now is empty ! ------------");
	      }else {
	      System.out.println("------Trickpile now is : ["+TrickPile.tp.get(TrickPile.tp.size()-1).getName()+"]------");
	      }
	      if(TrickDeck.td.size()==0) {
	    	  System.out.println("------------ TrickDeck now is empty ! ------------");
	      }
	      
	      for(int n=0; n<3;n++) {//show the props have been flipped
	       if(PartieDeJeu.playerlist.get(n).getPropleft().getMark()==true&&n!=i) 
	    	   System.out.println("---Player "+n+"'s left prop is : " +"["+PartieDeJeu.playerlist.get(n).getPropleft().getName()+"]---");
	       if(PartieDeJeu.playerlist.get(n).getPropright().getMark()==true&&n!=i)
	    	   System.out.println("---Player "+n+"'s right prop is : " +"["+PartieDeJeu.playerlist.get(n).getPropright().getName()+"]---");
	      }

	      
		  System.out.println("------------Choose TrickDeck or TrickPile ?-------------11111");
		  System.out.println("------------ 1 = TrickDeck , 2 = TrickPile -------------");
		  int[] choosetrick =readInt();
	      trick = PartieDeJeu.playerlist.get(i).chooseTrick(partie.trickdeck, partie.trickpile, choosetrick[0]);
	      
	      
	      int[] chooseProp = readInt();
	      PartieDeJeu.playerlist.get(i).swapProp(PartieDeJeu.playerlist.get(chooseProp[0]), chooseProp[1], chooseProp[2]);
		
	      this.success = PartieDeJeu.playerlist.get(i).performTrick(trick, partie.trickdeck, partie.trickpile, partie.prop7th);
	      
	      
		if(success) {
			int[] newProp = readInt();
			PartieDeJeu.playerlist.get(i).rearrange(newProp[0], newProp[1], partie.prop7th);
			if(trick.getName()=="The_Other_Hat_Trick") {
				gameover = true;
				winner = partie.winner1();
			}
		}else {
			if(trick.getName()=="The_Other_Hat_Trick"&&trick.failtime==3) {
				gameover = true;
				winner = partie.winner2();
			}
			else {
				int[] flip = readInt();
				PartieDeJeu.playerlist.get(i).flipProp(flip[0]);
			}
		}
	}
	/**
	 * The actions that virtual players take each tour.
	 * 
	 * @param i the number of player
	 */
	public void virtualplayer(int i) {
		Trick trick;
		int nothing =-1;

		System.out.println();
		System.out.println("------------------Now is AI : Player "+i+" -------------------");		 
	    trick = PartieDeJeu.playerlist.get(i).chooseTrick(partie.trickdeck, partie.trickpile, 1);
	      
	    PartieDeJeu.playerlist.get(i).swapProp(PartieDeJeu.playerlist.get(i), nothing, nothing);
			

		boolean success = PartieDeJeu.playerlist.get(i).performTrick(trick, partie.trickdeck, partie.trickpile, partie.prop7th);
		
		if(success) {		
			PartieDeJeu.playerlist.get(i).rearrange(nothing, nothing, partie.prop7th);
			if(TrickDeck.td.size()==0) {
				gameover = true;
				winner = partie.winner1();
			}
		}else {
			if(TrickPile.tp.get(TrickPile.tp.size()-1).failtime > 3) {
				gameover = true;
				winner = partie.winner2();
			}
			else {
				PartieDeJeu.playerlist.get(i).flipProp(nothing);
			}
			
		} 
			
		}

	
	
}