package vue;
import modele.*;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JCheckBox;
import javax.swing.JTextField;

import controleur.*;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;
/**
 * Class Moninterface is a responsible for the graphical interface.
 * 
 * This class implements interface observer and two frames are constructed in
 * this class : frame 1 and frame 2.
 * <p>
 * Frame 1 is used to initialize the number of real players, real
 * players' ages and the mode. Frame 2 is the main frame of this game.
 * 
 *
 */
public class MonInterface implements Observer{

	private JFrame frame;
	private JTextField textFieldAge_1;
	private JTextField textFieldAge_2;
	private JTextField textFieldAge_3;
	private JCheckBox checkboxPlayer_1;
	private JCheckBox checkboxPlayer_2;
	private JCheckBox checkboxPlayer_3;
	private JCheckBox checkboxEasy;
	private JCheckBox checkboxHard;
	private JButton buttonStartGame;
	private JLabel lblMode;
	private JLabel lblAge;
	
	private PartieDeJeu partiedejeu;
	
	private JFrame frame2;
	private JButton buttonTrickdeck;
	private JButton buttonTrickpile;
	private JButton buttonProp7th;
	private JButton buttonProp_1;
	private JButton buttonProp_2;
	private JButton buttonProp_3;
	private JButton buttonProp_4;
	private JButton buttonProp_5;
	private JButton buttonProp_6;
	private JButton buttonNext;
	private JButton buttonSwapprop;
	private JButton buttonFlipprop;
	private JButton buttonRearrange;
	private JTextField textField;
	private JTextField textField_1;
	
	/**
	 * When there is a change notified, the operation update will be called
	 * and it will checkout the notification is from which Observable and what has been changed
	 * to take corresponding measures.
	 * 
	 * @param instanceObservable is the one who notify the observer.
	 * @param o is something which the observable want to notify.
	 */
	public void update(Observable instanceObservable, Object o) {
		if(instanceObservable instanceof TrickPile) {
			if(TrickPile.tp.size()!=0) {
				String adresse=chooseTrickPicture(TrickPile.tp.get(TrickPile.tp.size()-1));
				buttonTrickpile.setIcon(new ImageIcon(adresse));
			}
			else {
				buttonTrickpile.setIcon(new ImageIcon("src\\images\\vide.jpg"));
			}
		}
		
		if(instanceObservable instanceof TrickDeck) {
			if(TrickDeck.td.size()==0)
				buttonTrickdeck.setIcon(new ImageIcon("src\\images\\vide.jpg"));
		}
		
		if(instanceObservable instanceof Prop7th) {
			String adresse=choosePropPicture(Prop7th.p7);
			if(Prop7th.p7.getMark()==true) 
				buttonProp7th.setIcon(new ImageIcon(adresse));
			else
				buttonProp7th.setIcon(new ImageIcon("src\\images\\back.jpg"));
		}
		
		if(instanceObservable instanceof Player&& o instanceof String) {
			String adresse=null;
				switch(PartieDeJeu.playerlist.indexOf((Player)instanceObservable)) {
				case 0 : 
					if(((Player)instanceObservable).getPropleft().getMark()==true) {
						adresse=choosePropPicture(((Player)instanceObservable).getPropleft());
						buttonProp_5.setIcon(new ImageIcon(adresse));
					}
					else {
							buttonProp_5.setIcon(new ImageIcon("src\\images\\back.jpg"));
					}
					if(((Player)instanceObservable).getPropright().getMark()==true) {
						adresse=choosePropPicture(((Player)instanceObservable).getPropright());
						buttonProp_6.setIcon(new ImageIcon(adresse));
					}
					else {
						buttonProp_6.setIcon(new ImageIcon("src\\images\\back.jpg"));
					}
					break;
				case 1:
					if(((Player)instanceObservable).getPropleft().getMark()==true) {
						adresse=choosePropPicture(((Player)instanceObservable).getPropleft());
						buttonProp_1.setIcon(new ImageIcon(adresse));
					}
					else
						buttonProp_1.setIcon(new ImageIcon("src\\images\\back.jpg"));
					if(((Player)instanceObservable).getPropright().getMark()==true) {
						adresse=choosePropPicture(((Player)instanceObservable).getPropright());
						buttonProp_2.setIcon(new ImageIcon(adresse));
					}
					else
						buttonProp_2.setIcon(new ImageIcon("src\\images\\back.jpg"));
					break;
				case 2:
					if(((Player)instanceObservable).getPropleft().getMark()==true) {
						adresse=choosePropPicture(((Player)instanceObservable).getPropleft());
						buttonProp_3.setIcon(new ImageIcon(adresse));
					}
					else
						buttonProp_3.setIcon(new ImageIcon("src\\images\\back.jpg"));
					if(((Player)instanceObservable).getPropright().getMark()==true) {
						adresse=choosePropPicture(((Player)instanceObservable).getPropright());
						buttonProp_4.setIcon(new ImageIcon(adresse));
					}
					else
						buttonProp_4.setIcon(new ImageIcon("src\\images\\back.jpg"));	
					break;
				}
			
			
		}
		
		
		
	}

	/**
	 * Create and launch the application.
	 */
	public static void main(String[] args) {
		PartieDeJeu monpartie=new PartieDeJeu();
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MonInterface window = new MonInterface(monpartie);
					window.frame.setVisible(true);
					window.frame2.setVisible(false);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
	}

	/**
	 * The constructor of the moninterface.
	 * 
	 * @param partie is the 
	 */
	public MonInterface(PartieDeJeu partie) {
		initializeframe();
		initializeframe2();
		
		this.partiedejeu=partie;
		partiedejeu.trickdeck.addObserver(this);
		partiedejeu.trickpile.addObserver(this);
		partiedejeu.prop7th.addObserver(this);
		
		new ControleurStarteGame(this,partie,buttonStartGame, frame, frame2,checkboxPlayer_1,checkboxPlayer_2,checkboxPlayer_3,checkboxEasy,checkboxHard,textFieldAge_1,textFieldAge_2,textFieldAge_3);
		new ControleurFrame2(partie,buttonTrickdeck,buttonTrickpile,buttonProp7th,buttonProp_1,buttonProp_2,buttonProp_3,buttonProp_4,buttonProp_5,buttonProp_6,buttonNext,buttonSwapprop,buttonFlipprop,buttonRearrange,textField,textField_1);
		
	}
	

	/**
	 * Initialize the contents of the start frame.
	 */
	private void initializeframe() {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Calibri", Font.PLAIN, 15));
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		checkboxPlayer_1 = new JCheckBox("1 Player");
		checkboxPlayer_1.setFont(new Font("Calibri", Font.PLAIN, 15));
		checkboxPlayer_1.setBounds(6, 6, 93, 23);
		frame.getContentPane().add(checkboxPlayer_1);
		
		checkboxPlayer_2 = new JCheckBox("2 Player");
		checkboxPlayer_2.setFont(new Font("Calibri", Font.PLAIN, 15));
		checkboxPlayer_2.setBounds(134, 6, 93, 23);
		frame.getContentPane().add(checkboxPlayer_2);
		
		checkboxPlayer_3 = new JCheckBox("3 Player");
		checkboxPlayer_3.setFont(new Font("Calibri", Font.PLAIN, 15));
		checkboxPlayer_3.setBounds(261, 6, 102, 23);
		frame.getContentPane().add(checkboxPlayer_3);
		
		checkboxEasy = new JCheckBox("Easy");
		checkboxEasy.setFont(new Font("Calibri", Font.PLAIN, 15));
		checkboxEasy.setBounds(93, 79, 66, 23);
		frame.getContentPane().add(checkboxEasy);
		
		checkboxHard = new JCheckBox("Hard");
		checkboxHard.setFont(new Font("Calibri", Font.PLAIN, 15));
		checkboxHard.setBounds(194, 79, 63, 23);
		frame.getContentPane().add(checkboxHard);
		
		textFieldAge_1 = new JTextField();
		textFieldAge_1.setBounds(93, 145, 66, 21);
		frame.getContentPane().add(textFieldAge_1);
		textFieldAge_1.setColumns(10);
		
		textFieldAge_2 = new JTextField();
		textFieldAge_2.setBounds(177, 145, 66, 21);
		frame.getContentPane().add(textFieldAge_2);
		textFieldAge_2.setColumns(10);
		
		textFieldAge_3 = new JTextField();
		textFieldAge_3.setBounds(261, 145, 66, 21);
		frame.getContentPane().add(textFieldAge_3);
		textFieldAge_3.setColumns(10);
		
		buttonStartGame = new JButton("Start Game");
		buttonStartGame.setFont(new Font("Calibri", Font.PLAIN, 15));
		buttonStartGame.setBounds(155, 206, 121, 34);
		frame.getContentPane().add(buttonStartGame);
		
		lblMode = new JLabel("Mode");
		lblMode.setFont(new Font("Calibri", Font.PLAIN, 15));
		lblMode.setBounds(11, 83, 49, 15);
		frame.getContentPane().add(lblMode);
		
		lblAge = new JLabel("Age");
		lblAge.setFont(new Font("Calibri", Font.PLAIN, 15));
		lblAge.setBounds(11, 148, 42, 15);
		frame.getContentPane().add(lblAge);
	}
	/**
	 * Initialize the contents of the game frame.
	 */
	private void initializeframe2() {
		frame2=new JFrame();
		frame2.getContentPane().setFont(new Font("Calibri", Font.PLAIN, 15));
		frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame2.setBounds(100, 100, 700, 600);
		frame2.getContentPane().setLayout(null);
		
		buttonTrickdeck = new JButton("TrickDeck");
		buttonTrickdeck.setIcon(new ImageIcon("src\\images\\back_1.jpg"));
		buttonTrickdeck.setFont(new Font("Calibri", Font.PLAIN, 8));
		buttonTrickdeck.setBounds(304, 10, 174, 116);
		frame2.getContentPane().add(buttonTrickdeck);
		
		buttonTrickpile = new JButton("TrickPile");
		buttonTrickpile.setIcon(new ImageIcon("src\\images\\vide.jpg"));
		buttonTrickpile.setFont(new Font("Calibri", Font.PLAIN, 8));
		buttonTrickpile.setBounds(500, 10, 174, 116);
		frame2.getContentPane().add(buttonTrickpile);
		
		buttonProp7th = new JButton("Prop7th");
		buttonProp7th.setIcon(new ImageIcon("src\\images\\back.jpg"));
		buttonProp7th.setFont(new Font("Calibri", Font.PLAIN, 8));
		buttonProp7th.setBounds(289, 169, 100, 130);
		frame2.getContentPane().add(buttonProp7th);
		
		buttonProp_1 = new JButton("");
		buttonProp_1.setIcon(new ImageIcon("src\\images\\back.jpg"));
		buttonProp_1.setBounds(10, 169, 100, 130);
		frame2.getContentPane().add(buttonProp_1);
		
		buttonProp_2 = new JButton("");
		buttonProp_2.setIcon(new ImageIcon("src\\images\\back.jpg"));
		buttonProp_2.setBounds(120, 169, 100, 130);
		frame2.getContentPane().add(buttonProp_2);
		
		buttonProp_3 = new JButton("");
		buttonProp_3.setIcon(new ImageIcon("src\\images\\back.jpg"));
		buttonProp_3.setBounds(461, 169, 100, 130);
		frame2.getContentPane().add(buttonProp_3);
		
		buttonProp_4 = new JButton("");
		buttonProp_4.setIcon(new ImageIcon("src\\images\\back.jpg"));
		buttonProp_4.setBounds(574, 169, 100, 130);
		frame2.getContentPane().add(buttonProp_4);
		
		buttonProp_5 = new JButton("");
		buttonProp_5.setIcon(new ImageIcon("src\\images\\back.jpg"));
		buttonProp_5.setBounds(193, 384, 100, 130);
		frame2.getContentPane().add(buttonProp_5);
		
		buttonProp_6 = new JButton("");
		buttonProp_6.setIcon(new ImageIcon("src\\images\\back.jpg"));
		buttonProp_6.setBounds(319, 384, 100, 130);
		frame2.getContentPane().add(buttonProp_6);
		
		JLabel lblTrickdeck = new JLabel("TrickDeck");
		lblTrickdeck.setFont(new Font("Calibri", Font.PLAIN, 15));
		lblTrickdeck.setBounds(357, 127, 72, 32);
		frame2.getContentPane().add(lblTrickdeck);
		
		JLabel lblTrickpile = new JLabel("TrickPile");
		lblTrickpile.setFont(new Font("Calibri", Font.PLAIN, 15));
		lblTrickpile.setBounds(546, 127, 80, 32);
		frame2.getContentPane().add(lblTrickpile);
		
		JLabel lblPropth = new JLabel("Prop7th");
		lblPropth.setFont(new Font("Calibri", Font.PLAIN, 15));
		lblPropth.setBounds(304, 303, 69, 27);
		frame2.getContentPane().add(lblPropth);
		
		JLabel lblProp = new JLabel("P0 Prop1");
		lblProp.setFont(new Font("Calibri", Font.PLAIN, 15));
		lblProp.setBounds(215, 519, 71, 32);
		frame2.getContentPane().add(lblProp);
		
		JLabel lblProp_1 = new JLabel("P0 Prop2");
		lblProp_1.setFont(new Font("Calibri", Font.PLAIN, 15));
		lblProp_1.setBounds(337, 524, 72, 23);
		frame2.getContentPane().add(lblProp_1);
		
		buttonNext = new JButton("NextPlayer");
		buttonNext.setFont(new Font("Calibri", Font.PLAIN, 15));
		buttonNext.setBounds(538, 505, 113, 37);
		frame2.getContentPane().add(buttonNext);
		
		JLabel lblPleftProp = new JLabel("P1 Prop1");
		lblPleftProp.setFont(new Font("Calibri", Font.PLAIN, 15));
		lblPleftProp.setBounds(20, 300, 80, 32);
		frame2.getContentPane().add(lblPleftProp);
		
		JLabel lblPleftProp_1 = new JLabel("P1 Prop2");
		lblPleftProp_1.setFont(new Font("Calibri", Font.PLAIN, 15));
		lblPleftProp_1.setBounds(130, 305, 72, 23);
		frame2.getContentPane().add(lblPleftProp_1);
		
		JLabel lblPrightProp = new JLabel("P2 Prop1");
		lblPrightProp.setFont(new Font("Calibri", Font.PLAIN, 15));
		lblPrightProp.setBounds(471, 300, 72, 32);
		frame2.getContentPane().add(lblPrightProp);
		
		JLabel lblPrightProp_1 = new JLabel("P2 Prop2");
		lblPrightProp_1.setFont(new Font("Calibri", Font.PLAIN, 15));
		lblPrightProp_1.setBounds(584, 303, 77, 27);
		frame2.getContentPane().add(lblPrightProp_1);
		
		buttonSwapprop = new JButton("SwapProp");
		buttonSwapprop.setFont(new Font("Calibri", Font.PLAIN, 15));
		buttonSwapprop.setBounds(538, 367, 105, 38);
		frame2.getContentPane().add(buttonSwapprop);
		
		buttonFlipprop = new JButton("FlipProp");
		buttonFlipprop.setFont(new Font("Calibri", Font.PLAIN, 15));
		buttonFlipprop.setBounds(538, 415, 108, 33);
		frame2.getContentPane().add(buttonFlipprop);
		
		buttonRearrange = new JButton("Rearrange");
		buttonRearrange.setFont(new Font("Calibri", Font.PLAIN, 15));
		buttonRearrange.setBounds(538, 458, 113, 37);
		frame2.getContentPane().add(buttonRearrange);
		
		textField = new JTextField();
		textField.setBounds(12, 28, 264, 32);
		frame2.getContentPane().add(textField);
		textField.setColumns(10);
		textField.setText("Click TrcikDeck");
		
		textField_1 = new JTextField();
		textField_1.setBounds(10, 70, 266, 32);
		frame2.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
	}
	/**
	 * This is the operation to output the path of the corresponding prop.
	 * 
	 * @param p is the corresponding prop.
	 * @return the path of the corresponding prop.
	 */
	public String choosePropPicture(Prop p) {
		String adresse=null;
		switch(p.getPropCard()) {
		case The_Lettuce : adresse="src\\images\\The_Lettuce.jpg"; break;
		case Carrots : adresse="src\\images\\Carrots.jpg"; break;
		case The_Hat : adresse="src\\images\\The_Hat.jpg"; break;
		case The_Rabbit :adresse="src\\images\\The_Rabbit.jpg"; break;
		case The_Other_Rabbit :adresse="src\\images\\The_Other_Rabbit.jpg";break;
		}
		return adresse;
		
	}
	/**
	 * This is the operation to output the path of the corresponding trick.
	 * 
	 * @param p is the corresponding trick.
	 * @return the path of the corresponding trick.
	 */
	public String chooseTrickPicture(Trick t) {
		String adresse=null;
		if(t.getName()=="The_Hungry_Rabbit") {
			adresse="src\\images\\Trick1.jpg";
		}
		if(t.getName()=="The_Vegetable_Hat_Trick") {
			adresse="src\\images\\Trick2.1.jpg";
		}
		if(t.getName()=="The_Bunch_of_Carrots") {
			adresse="src\\images\\Trick2.jpg";
		}
		if(t.getName()=="The_Vegetable_Patch") {
			adresse="src\\images\\Trick3.1.jpg";
		}
		if(t.getName()=="The_Carrot_Hat_Trick") {
			adresse="src\\images\\Trick3.jpg";
		}
		if(t.getName()=="The_Slightly_Easier_Hat_Trick") {
			adresse="src\\images\\Trick4.1.jpg";
		}
		if(t.getName()=="The_Rabbit_That_Didn't_Like_Carrots") {
			adresse="src\\images\\Trick4.jpg";
		}
		if(t.getName()=="The_Hat_Trick") {
			adresse="src\\images\\Trick5.1.jpg";
		}
		if(t.getName()=="The_Pair_of_Rabbits") {
			adresse="src\\images\\Trick5.jpg";
		}
		if(t.getName()=="The_Other_Hat_Trick") {
			adresse="src\\images\\Trick6.jpg";
		}
		return adresse;
			
		
	}
}
